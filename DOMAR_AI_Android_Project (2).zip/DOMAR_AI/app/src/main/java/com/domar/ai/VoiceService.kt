package com.domar.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var waitingForCommand = false
    private var listening = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification())
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
            listenAgain()
        } else speak("Распознавание речи недоступно на этом устройстве")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ready = true
            tts?.language = Locale("ru", "RU")
            // If an English UK voice is installed, it can be selected in a later settings screen.
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(error: Int) {
            listening = false
            listenAgain()
        }
        override fun onResults(results: android.os.Bundle?) {
            listening = false
            val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.lowercase(Locale("ru", "RU")).orEmpty()
            handlePhrase(phrase)
            listenAgain()
        }
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    }

    private fun handlePhrase(text: String) {
        if (text.isBlank()) return
        if (!waitingForCommand && (text.contains("джарвис") || text.contains("jarvis"))) {
            waitingForCommand = true
            speak("Слушаю вас")
            return
        }
        if (waitingForCommand) {
            waitingForCommand = false
            when {
                text.contains("ютуб") || text.contains("youtube") -> {
                    openApp("com.google.android.youtube", "Открываю YouTube")
                }
                text.contains("браузер") || text.contains("интернет") -> {
                    openApp("com.android.chrome", "Открываю браузер")
                }
                text.contains("настройки") -> {
                    speak("Открываю настройки")
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                text.contains("стоп") || text.contains("остановись") -> speak("Хорошо")
                else -> speak("Пока я умею выполнять базовые команды. Команда получена: $text")
            }
        }
    }

    private fun openApp(packageName: String, response: String) {
        speak(response)
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else speak("Это приложение не найдено")
    }

    private fun speak(message: String) {
        if (ready) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "domar_ai")
    }

    private fun listenAgain() {
        if (recognizer == null || listening) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            listening = false
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "domar_voice", "DOMAR AI", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "domar_voice")
                .setContentTitle("DOMAR AI активен")
                .setContentText("Скажите «Джарвис», чтобы вызвать помощника")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("DOMAR AI активен")
                .setContentText("Скажите «Джарвис», чтобы вызвать помощника")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .build()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
